import { BUY_BOOK } from "./bookType";

//action
export const buyBook = () => {
  return {
    type: BUY_BOOK,
  };
};
