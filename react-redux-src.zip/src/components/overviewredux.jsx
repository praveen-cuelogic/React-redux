import React from "react";

function overviewredux() {
  return (
    <div>
      step_1: your react app step_2: 1- create action_type like:BUY_BOOK
      2-create a function which return a action 3- craete reducer: initiate vale
      of state, the reducer =(state =initiate, action ) switch statement step3:
      create store and call reducer step4: go to your root app and pass there
      state all comp using <provider store={store}>call component</provider>
      step5: component : there is mapStatetoProps and mapDispatchtoPrps connect
      both using connect function with comp -----------------------------
    </div>
  );
}

export default overviewredux;
