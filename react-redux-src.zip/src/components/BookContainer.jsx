import React from "react";
import { connect } from "react-redux";
import { buyBook } from "../redux";

function bookContainer(props) {
  return (
    <div>
      <h1>Number of Books- {props.numOfBooks}</h1>
      <button onClick={props.buyBook}>Buy Book</button>
    </div>
  );
}

//value of state map into props
const mapStatetoProps = (state) => {
  return {
    numOfBooks: state.numberOfBooks,
  };
};

//value of dispatch map into props
const mapDispatchtoProps = (dispatch) => {
  return {
    buyBook: function () {
      dispatch(buyBook());
    },
  };
};

//which value we are passing that is via: state and
//Using function of dispatch for bookContainerComponent
export default connect(mapStatetoProps, mapDispatchtoProps)(bookContainer);
